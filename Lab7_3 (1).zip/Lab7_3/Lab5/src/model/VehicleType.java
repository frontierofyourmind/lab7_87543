package src.model;

/**
 * Enum, содержащий типы транспортных средств
 */
public enum VehicleType {
    BOAT,
    MOTORCYCLE,
    CHOPPER;
}
package src.model;

/**
 * Enum, содержащий типы топлива
 */
public enum FuelType {
    GASOLINE,
    KEROSENE,
    MANPOWER,
    PLASMA,
    ANTIMATTER;
}